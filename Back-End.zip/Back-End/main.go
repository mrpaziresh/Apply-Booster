package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"

	"github.com/ledongthuc/pdf"
	"github.com/rs/cors"
)

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/upload-pdf", uploadPDFHandler)
	mux.HandleFunc("/check-save-status", checkSaveStatusHandler)
	mux.HandleFunc("/hello", helloHandler) // Add helloHandler to handle /hello endpoint

	handler := cors.Default().Handler(mux)

	fmt.Println("Server listening on port 8080")
	http.ListenAndServe(":8080", handler)
}

// Define a global variable to track the save status
var fileSaved bool

func uploadPDFHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Parse multipart form
	err := r.ParseMultipartForm(10 << 20) // 10 MB max file size
	if err != nil {
		http.Error(w, "Unable to parse form", http.StatusBadRequest)
		return
	}

	file, _, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "Missing file field", http.StatusBadRequest)
		return
	}
	defer file.Close()

	// Create a directory to store uploaded PDF files if it doesn't exist
	uploadsDir := "./uploads"
	if _, err := os.Stat(uploadsDir); os.IsNotExist(err) {
		os.Mkdir(uploadsDir, 0755)
	}

	// Create a temporary file to store the uploaded PDF
	tempFile, err := ioutil.TempFile(uploadsDir, "uploaded-*.pdf")
	if err != nil {
		http.Error(w, "Unable to create temporary file", http.StatusInternalServerError)
		return
	}
	defer tempFile.Close()

	// Copy the uploaded file content to the temporary file
	_, err = io.Copy(tempFile, file)
	if err != nil {
		http.Error(w, "Unable to save file", http.StatusInternalServerError)
		return
	}

	// Extract text from the uploaded PDF
	text, err := extractTextFromPDF(tempFile.Name())
	if err != nil {
		http.Error(w, "Unable to extract text from PDF", http.StatusInternalServerError)
		return
	}

	// Send response with extracted text
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(text))
}

func extractTextFromPDF(filePath string) (string, error) {
	f, r, err := pdf.Open(filePath)
	if err != nil {
		return "", err
	}
	defer f.Close()

	var buf bytes.Buffer
	b, err := r.GetPlainText()
	if err != nil {
		return "", err
	}
	buf.ReadFrom(b)

	return buf.String(), nil
}

func checkSaveStatusHandler(w http.ResponseWriter, r *http.Request) {
	// Perform any necessary checks to determine the save status
	// For demonstration purposes, we'll just set a dummy save status
	fileSaved := true

	// Respond with a JSON message indicating the save status
	response := map[string]bool{"fileSaved": fileSaved}
	jsonResponse, err := json.Marshal(response)
	if err != nil {
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(jsonResponse)
}

func helloHandler(w http.ResponseWriter, r *http.Request) {
	// Extract text from a sample PDF file
	text, err := extractTextFromPDF("sample.pdf")
	if err != nil {
		http.Error(w, "Failed to extract text", http.StatusInternalServerError)
		return
	}

	// Send the extracted text as the response
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(text))
}
